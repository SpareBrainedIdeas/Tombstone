Business Central inspired Word Cloud Wallpaper pack provided by Jeremy Vyska of Spare Brained Ideas AB.

https://sparebrained.com/


Space Layer Adapted from Unsplash artwork by Wil Stewart: https://unsplash.com/@wilstewart3
  
Brilliant Colors art from Unsplash artwork by Pawel Czerwinski: https://unsplash.com/@pawel_czerwinski


This pack is released under the Creative Commons -- Attribution 4.0 Internaional
(CC BY 4.0) license: https://creativecommons.org/licenses/by/4.0/

This is a human-readable summary of (and not a substitute for) the license:
---------------------------------------------------------------------------
You are free to:
	Share — copy and redistribute the material in any medium or format
	Adapt — remix, transform, and build upon the material for any purpose, even commercially.

	This license is acceptable for Free Cultural Works.
	The licensor cannot revoke these freedoms as long as you follow the license terms.

Under the following terms:

	Attribution — You must give appropriate credit, provide a link to the license, 
	and indicate if changes were made. You may do so in any reasonable manner, but 
	not in any way that suggests the licensor endorses you or your use.

	No additional restrictions — You may not apply legal terms or technological 
	measures that legally restrict others from doing anything the license permits.